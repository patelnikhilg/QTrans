﻿using System;

namespace QTrans.Utility
{
    public class DefaultConstants
    {
    }
}
