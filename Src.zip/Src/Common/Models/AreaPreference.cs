﻿namespace QTrans.Models
{
    public class AreaPreference
    {
        public long preferenceId { get; set; }
        public long UserId { get; set; }

        public string Area { get; set; }

    }  
}
