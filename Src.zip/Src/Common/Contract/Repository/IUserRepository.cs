﻿using System;
using System.Collections.Generic;
using System.Text;

namespace QTrans.Contract.Repository
{
    public interface IUserRepository: IRepository<IEntity>
    {
    }
}
