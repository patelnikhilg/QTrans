﻿using System;
using System.Collections.Generic;
using System.Text;

namespace QTrans.Contract
{
    public interface IEntity
    {
        Int64 Id { get; }
    }
}
